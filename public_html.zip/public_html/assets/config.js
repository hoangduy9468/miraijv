// cpanel - site_templates/countdown_fresh/assets/config.js.tt Copyright(c) 2016 cPanel, Inc.
//                                                          All rights Reserved.
// copyright@cpanel.net                                        http://cpanel.net
// This code is subject to the cPanel license. Unauthorized copying is prohibited

window.cpanel = {
    data: {
        email: "stitsoftware@gmail.com",
        logo: "My Demo",
        social: [
            
            
            
            
            
            
        ]
    },
    style: {
        primary: "",
    },
    slides: [
        {
            type: 'countdown',
            backgroundImage: "",
            backgroundColor: "",
            color: "",
            buttonText: "Button Demo",
            buttonLink: "",
            endTime: '',
            content: "Demo noi dung",
        }
    ]
};
